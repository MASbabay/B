# BJM Lite — Android 7+

Clone fungsi utama versi ringan berbasis Android WebView. `minSdk 24` berarti Android 7.0 (API 24) atau lebih baru.

## Build APK otomatis (tanpa Android Studio)

1. Ekstrak folder `BJM-Lite` dari ZIP ini.
2. Buat repository baru di GitHub, misalnya `bjm-lite-android`.
3. Upload seluruh isi folder `BJM-Lite` ke repository (pastikan `.github/workflows/build-apk.yml` ikut ter-upload) dan simpan pada branch `main`.
4. Buka tab **Actions** di repository GitHub. Workflow **Build BJM Lite APK** akan berjalan otomatis setelah push. Jika belum berjalan, pilih workflow itu lalu tekan **Run workflow**.
5. Setelah status selesai dengan tanda hijau, buka hasil run dan unduh artifact **BJM-Lite-Android7-APK**.
6. Ekstrak artifact ZIP. File `app-debug.apk` adalah APK yang dapat dipasang. Di Android, izinkan instalasi dari sumber yang digunakan bila diminta.

Workflow memakai JDK 17 dan Gradle 8.2.1 untuk membangun dengan Android Gradle Plugin 8.2.2. APK debug ditandatangani otomatis dengan debug key oleh Android Gradle Plugin; cocok untuk instalasi/uji, bukan distribusi Play Store.

## Fitur pada build awal
- Dashboard live data (RPM, TPS, AFR/O2, ECT, baterai, ignition) bila firmware mengirim JSON dengan key yang dikenali.
- Diagnosis DTC: `GET /read-dtc`; hapus DTC: `GET /clear-dtc`.
- Mulai baca ECU: `GET /read-ecu-start?type=...`.
- Editor BIN dasar: buka file, lihat hex, ubah satu byte, simpan salinan, dan upload ke SD melalui `POST /upload?folder=/`.
- Database ECU dari APK sumber disertakan sebagai referensi.
- Koneksi default ESP32: `192.168.4.1`, WebSocket `/ws`.

## Batasan dan keselamatan

Ini bukan pengganti penuh aplikasi/perangkat sumber. Parser live data masih generik dan harus disesuaikan dengan firmware. Database ECU belum dihubungkan ke editor map visual. Checksum otomatis dan flashing tidak diaktifkan. Jangan gunakan file BIN hasil edit untuk flashing sebelum ukuran, alamat, checksum, definisi map, dan kompatibilitas ECU diverifikasi di hardware yang sesuai. Hapus DTC juga mengirim perintah ke ECU; gunakan hanya setelah memastikan tindakan tersebut aman.

Pengaturan WebView mengizinkan akses jaringan dari aset lokal agar komunikasi HTTP/WebSocket ke ESP32 dapat berjalan. Hubungkan hanya ke perangkat/jaringan yang dipercaya.
